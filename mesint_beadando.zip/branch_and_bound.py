import time


class BranchAndBound:
    nodes = {}
    index = 'S'
    to_add = 0
    global_min = 99999
    possible_next_nodes = []
    is_g_reached = False
    current_path = 'S'
    previous_paths = set()
    best_path = ''
    is_algorithm_ended = False
    extensions = 0
    extended_list: set[int] = set()
    goal_index = 'G'
    version = ''
    heuristic_distances = {}
    heu = 0

    def __init__(self, nodes: dict[str:list], version: str, heuristic_distances: dict[str:int] = None):
        self.nodes = nodes
        self.version = version
        if heuristic_distances is not None:
            self.heuristic_distances = heuristic_distances

    def algorithm(self):
        start = time.time()
        self.possible_next_nodes.clear()
        while True:
            print(self.index, end="")
            self.read_neighbours()
            self.get_least_value_node()
            self.current_path += self.index
            if self.is_algorithm_ended:
                print()
                print(f'Extensions: {self.extensions}')
                print(f'Time elapsed: {time.time() - start}s')
                return self.best_path

    def read_neighbours(self):
        insertion_index = 0
        continue_outer_for_loop = False
        for neighbour in self.nodes[self.index]:
            for key, value in neighbour.items():
                self.extensions += 1
                value += self.to_add
                if self.version == 'heuristic':
                    value += self.heuristic_distances[key]
                if key == self.goal_index:
                    self.current_path += key
                    print(key, end="")
                    if value < self.global_min:
                        self.best_path = self.current_path
                        self.current_path = 'G'
                        self.global_min = value
                    self.is_g_reached = True
                    continue_outer_for_loop = True
                    continue
                self.possible_next_nodes.insert(insertion_index, {key: value})
            if continue_outer_for_loop:
                continue
            insertion_index += 1

    def get_least_value_node(self):
        min_value = 999999
        key_to_continue = ''
        for obj in self.possible_next_nodes:
            key = list(obj.keys())[0]
            value = list(obj.values())[0]
            if self.version == 'extended list':
                if key in self.extended_list:
                    continue
            if value < min_value:
                min_value = value
                key_to_continue = key
        if key_to_continue == '':
            self.is_algorithm_ended = True
            return
        self.possible_next_nodes.remove({key_to_continue: min_value})

        if self.version == 'extended list':
            self.extended_list.add(key_to_continue)

        if self.is_g_reached:
            if min_value >= self.global_min:
                self.is_algorithm_ended = True
                return

        self.index = key_to_continue
        if self.version == 'heuristic':
            self.to_add = min_value - self.heuristic_distances[key_to_continue]
        else:
            self.to_add = min_value

