import bfs_and_dfs
from branch_and_bound import BranchAndBound


def populate_heuristic_values(first_line: str, heuristic_distances: dict[str:int]):
    to_slice = first_line.split(' ')
    for i in range(len(to_slice)):
        if i > 0:
            separate = to_slice[i].split('-')
            heuristic_distances.update({separate[0]: int(separate[1])})


def populate_nodes_with_values(file_name: str, names: set[str]):
    nodes = {}
    for name in names:
        nodes.update({name: []})

    with open(file_name) as f:
        lines = f.read().splitlines()

    i = 0
    for line in lines:
        if i == 0:
            i += 1
            continue

        split = line.split(' ')
        node_name = split[0]
        neighbour_name = split[1]
        value = int(split[2])

        nodes[node_name].append({neighbour_name: value})

    return nodes


def populate_nodes(file_name: str, names: set[str]):
    nodes = {}
    heuristic_distances = {}
    for name in names:
        nodes.update({name: []})

    with open(file_name) as f:
        # https://stackoverflow.com/questions/12330522/how-to-read-a-file-without-newlines
        lines = f.read().splitlines()

    i = 0
    for line in lines:
        if i == 0:
            populate_heuristic_values(line, heuristic_distances)
            i += 1

        split = line.split(' ')
        node_name = split[0]
        neighbour_name = split[1]
        nodes[node_name].append(neighbour_name)
    return nodes, heuristic_distances


def print_nodes(nodes: list):
    for n in nodes:
        print(n)


def branch_and_bounds(nodes: dict[str:list], heuristic_distances: dict[str:int]):
    names = ['basic', 'extended list', 'heuristic']
    for version in names:
        print('Branch and Bound ' + version)
        print('Nodes that were examined: ', end="")
        if version != 'heuristic':
            bnb = BranchAndBound(nodes, version)
        else:
            bnb = BranchAndBound(nodes, version, heuristic_distances)
        print(f'Best path: {bnb.algorithm()}')
        print()


def bfs_and_dfss(nodes: dict[str:list]):
    print(bfs_and_dfs.bfs(nodes, 'S', 'G'))
    # print(bfs_and_dfs.dfs(nodes, 'S', 'G'))


def hill_climbing(nodes, heuristic_distances):
    key = 'S'
    path = key
    key_to_continue = ''
    min_number = 99999
    is_algorithm_ended = False
    possible_next_nodes = []
    while True:
        min_number = 99999
        for current_node in nodes[key]:
            if current_node == 'G':
                path += current_node
                is_algorithm_ended = True
                break
            possible_next_nodes.append(current_node)

        if is_algorithm_ended:
            break

        for name in possible_next_nodes:
            value = heuristic_distances[name]
            if value < min_number:
                min_number = value
                key_to_continue = name
        possible_next_nodes.remove(key_to_continue)
        path += key_to_continue
        key = key_to_continue
    return path


def third_graph():
    node_names = {'S', 'X', 'Y', 'Z', 'W', 'G'}
    nodes, heuristic_distances = populate_nodes('datas/graph_3.txt', node_names)
    nodes_with_values = populate_nodes_with_values('datas/graph_3.txt', node_names)

    # bfs_and_dfss(nodes)
    # print(hill_climbing(nodes, heuristic_distances))
    branch_and_bounds(nodes_with_values, heuristic_distances)


def second_graph():
    node_names = {'S', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'X', 'Y'}
    nodes, heuristic_distances = populate_nodes('datas/graph_2.txt', node_names)
    nodes_with_values = populate_nodes_with_values('datas/graph_2.txt', node_names)

    # bfs_and_dfss(nodes)
    # print(hill_climbing(nodes, heuristic_distances))
    branch_and_bounds(nodes_with_values, heuristic_distances)


# TODO: Path fix, heuristic, Beam, A*, best-first
def main():
    second_graph()
    # third_graph()


if __name__ == "__main__":
    main()
